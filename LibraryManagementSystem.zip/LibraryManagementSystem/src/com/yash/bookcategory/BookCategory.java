package com.yash.bookcategory;

import com.yash.domain.Book;

public interface BookCategory {

	public Book getBookCategory(String category);
}
