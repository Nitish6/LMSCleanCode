package com.yash.controller;

public class Launcher {
	public static void main(String[] args) {
		LibraryManagement.getBookDetails();
	}
}
